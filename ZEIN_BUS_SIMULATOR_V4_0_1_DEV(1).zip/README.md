# ZEIN BUS SIMULATOR V4.0.1 — Development Build

## Kandungan
- `index.html` — halaman utama untuk hosting statik.
- `ZEIN_BUS_SIMULATOR_V4.html` — salinan bernama permainan web Three.js.
- `assets/LAKSA_KARI_SR2.obj` — model bas yang dibekalkan pengguna (nama paparan dalam permainan: LAKSA KARI SR2).
- `assets/BusGameMap.obj` — persekitaran bandar OBJ daripada ZIP aset yang dibekalkan.
- `assets/Low_Poly_City_Cars.obj` + `.mtl` + `tex/` — model kereta trafik dan teksturnya.
- `assets/ZEIN_BUS_BLUEPRINT_REFERENCE.png` — rujukan reka bentuk ZEIN.

## Cara menjalankan
1. Ekstrak keseluruhan ZIP.
2. Pastikan fail HTML dan folder `assets` berada dalam folder yang sama.
3. Jalankan melalui local web server atau deploy keseluruhan folder ke hosting statik seperti Vercel.
4. Buka `ZEIN_BUS_SIMULATOR_V4.html` dalam browser moden. Internet diperlukan untuk memuatkan Three.js daripada CDN.

Jangan buka fail HTML secara `file://` jika browser menyekat pemuatan aset OBJ; gunakan local server.

## Kawalan prototaip semasa
- Android: butang MINYAK, BREK, kiri, kanan, gear P/R/N/D.
- Kamera: luar, kokpit, depan, sisi.
- Wiper, pintu (kunci ketika bergerak), lampu dan hon.
- Trafik LOW/AUTO/HIGH (model kereta OBJ).
- Cuaca cerah/hujan asas dan siang/malam asas.
- Tetapan grafik disimpan secara lokal.

## Penambahbaikan V4.0.1
- Pertukaran gear D/R/P/N kini memerlukan bas berhenti hampir sepenuhnya.
- Kawalan pemanduan dilepaskan apabila permainan dijeda, tab hilang fokus atau browser disembunyikan.
- Enjin tidak lagi memecut apabila bahan api mencapai sifar.
- `index.html` ditambah supaya hosting statik membuka permainan pada halaman utama.

## Status pembangunan yang jujur
### Sudah dimasukkan dalam build ini
- Bas OBJ LAKSA KARI SR2 dimuatkan sebagai model bas utama.
- OBJ peta bandar dimuatkan sebagai persekitaran.
- OBJ kereta dan tekstur digunakan untuk kenderaan trafik.
- Kawalan pemanduan asas, gear, kamera dan UI prototaip.
- Simpanan seting grafik dan trafik melalui Local Storage.

### Belum siap / belum disahkan
- Fizik bas lanjutan, suspensi sebenar, transmisi lengkap dan kerosakan.
- Animasi pintu/wiper perlu diuji pada model sebenar; pivot OBJ mungkin memerlukan pelarasan.
- Traffic AI ikut lorong, simpang, lampu isyarat penuh dan collision avoidance.
- 44 penumpang dengan animasi naik/turun.
- Career Mode, Tour Mode enam destinasi, ekonomi, profil dan misi.
- Kokpit instrumen yang disegerakkan sepenuhnya dengan fizik.
- Cuaca hujan realistik, bunyi berlesen, peta Malaysia penuh.
- Terjemahan penuh BM/English.
- QA merentas pelbagai telefon Android dan prestasi map OBJ yang besar.

## Nota aset
Fail OBJ bas dan peta tidak mempunyai fail MTL masing-masing dalam bahan yang diterima. Oleh itu, bahan asas sementara digunakan. Model kereta mempunyai MTL dan tekstur yang disertakan. Pastikan syarat lesen/atribusi pencipta bagi setiap aset dipatuhi sebelum penerbitan.
